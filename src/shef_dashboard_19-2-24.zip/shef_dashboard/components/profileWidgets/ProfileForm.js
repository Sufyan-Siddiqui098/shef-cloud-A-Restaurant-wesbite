import React, { useState, useRef } from 'react'

export const ProfileForm = () => {
    const [selectedImage, setSelectedImage] = useState(null);
    const fileInputRef = useRef(null);
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                // Set the selected image in state
                setSelectedImage(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };
    const handleBoxClick = () => {
        // Trigger click on the hidden file input
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };
    return (
        <>
            <div className='p-5 rounded-xl border border-borderClr mb-6'>
                <h2 className='text-xl font-semibold border-b pb-2 mb-4'>Profile Info</h2>
                <form>
                    <div className=''>
                        <div className='w-[170px] h-[190px] border border-borderClr rounded-lg overflow-hidden relative cursor-pointer'
                            onClick={handleBoxClick}
                        >
                            {selectedImage ? (
                                <img
                                    src={selectedImage}
                                    alt="Selected"
                                    className='w-full h-full object-cover'
                                />
                            ) : (
                                <p className='text-center flex items-center justify-center text-sm text-[#777] h-full' >Click to add image</p>
                            )}
                        </div>
                        {/* Hidden file input */}
                        <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageChange}
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                        />
                        <h3 className='text-base font-semibold mb-1 uppercase mt-2'>Upload Your Photo</h3>
                    </div>
                    <div className='grid grid-cols-12 md:gap-x-8 gap-x-0 gap-y-4 mt-8'>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>First Name <span className='text-primary'>*</span></h4>
                            <input type="text" placeholder='Enter First Name' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Last Name </h4>
                            <input type="text" placeholder='Enter Last Name' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Email <span className='text-primary'>*</span></h4>
                            <input type="email" placeholder='Enter Email' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Country <span className='text-primary'>*</span></h4>
                            <select id="selectOption">
                                <option value="">Select Country</option>
                                <option value="option1">Option 1</option>
                                <option value="option2">Option 2</option>
                                <option value="option3">Option 3</option>
                            </select>
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>City <span className='text-primary'>*</span></h4>
                            <select id="selectOption">
                                <option value="">Select City</option>
                                <option value="option1">Option 1</option>
                                <option value="option2">Option 2</option>
                                <option value="option3">Option 3</option>
                            </select>
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Mobile Number <span className='text-primary'>*</span> </h4>
                            <input type="text" placeholder='Enter Mobile Number' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Home Address <span className='text-primary'>*</span> </h4>
                            <input type="text" placeholder='Enter Home Address' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Pickup Address <span className='text-primary'>*</span></h4>
                            <input type="text" placeholder='Enter Pickup Address' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Zip Code </h4>
                            <input type="text" placeholder='Enter Zip Code' id='' name='' />
                        </div>
                        <div className='md:col-span-6 col-span-12'>
                            <h4 className='text-base font-semibold mb-1 uppercase'>Password </h4>
                            <input type="password" placeholder='Enter Password' id='' name='' />
                        </div>
                    </div>
                </form>
            </div>
        </>
    )
}
export default ProfileForm