import React from 'react'
import { NavLink } from "react-router-dom"
import { Helmet } from 'react-helmet';
import '../assets/css/dash-style.css';
export const Header = () => {
    return (
        <>
            <Helmet>
                <title>Shef Dashboard | Shef Cloud</title>
                <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,500&display=swap" rel="stylesheet"></link>
            </Helmet>
            <div className='border-b border-borderClr h-[70px]'>
                <div className='px-4'>
                    <header className='py-3 '>
                        <div className="logo mainNavCol">
                            <NavLink>
                                {/* <img src="/media/frontend/img/logo/line-logo.jpg" width='' className="img-fluid h-[40px]" alt="Logo" /> */}
                            </NavLink>
                        </div>
                    </header>
                </div>
            </div>
        </>
    )
}
export default Header