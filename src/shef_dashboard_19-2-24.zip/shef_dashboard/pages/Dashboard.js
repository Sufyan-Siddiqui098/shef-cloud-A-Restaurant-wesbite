import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../../shef_dashboard/components/Header'
import Sidebar from '../components/Sidebar'
export const Dashboard = () => {
    return (
        <div className=''>
            <div className='grid grid-cols-12'>
                <div className='lg:col-span-3 col-span-12'>
                    <div className=''>
                        <Sidebar />
                    </div>
                </div>
                <div className='lg:col-span-9 col-span-12'>
                    <Header />
                    <div className='grid grid-cols-12 gap-4 p-5'>
                        <div className='lg:col-span-4 md:col-span-6 col-span-12'>
                            <Link>
                                <div className='rounded-xl p-5 border border-borderClr'>
                                    <div className='flex justify-between items-center gap-x-2'>
                                        <div className='bg-primaryLight p-3 rounded-lg inline-block'>
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="36" height="36" fill="rgba(0,0,0,1)">
                                                <path d="M14.2683 12.1466L13.4147 13.0002L20.4858 20.0712L19.0716 21.4854L12.0005 14.4144L4.92946 21.4854L3.51525 20.0712L12.854 10.7324C12.2664 9.27549 12.8738 7.17715 14.4754 5.57554C16.428 3.62292 19.119 3.14805 20.4858 4.51488C21.8526 5.88172 21.3778 8.57267 19.4251 10.5253C17.8235 12.1269 15.7252 12.7343 14.2683 12.1466ZM4.22235 3.80777L10.9399 10.5253L8.11144 13.3537L4.22235 9.46463C2.66026 7.90253 2.66026 5.36987 4.22235 3.80777ZM18.0109 9.11107C19.2682 7.85386 19.5274 6.38488 19.0716 5.92909C18.6158 5.47331 17.1468 5.73254 15.8896 6.98975C14.6324 8.24697 14.3732 9.71595 14.829 10.1717C15.2847 10.6275 16.7537 10.3683 18.0109 9.11107Z"></path>
                                            </svg>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32" fill="rgba(0,0,0,1)">
                                            <path d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z"></path>
                                        </svg>
                                    </div>
                                    <h2 className='text-xl font-semibold uppercase mt-5 mb-0'>Your first dish</h2>
                                    <p className='mb-0'>
                                        Add your first item now!
                                    </p>
                                </div>
                            </Link>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}
export default Dashboard