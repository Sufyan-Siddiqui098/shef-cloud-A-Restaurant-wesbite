import React from 'react'
import ProfileForm from '../components/profileWidgets/ProfileForm';
import ProfileDetail from '../components/profileWidgets/profileDetail';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export const Profile = () => {

    return (
        <>
            <div className='grid grid-cols-12'>
                <div className='lg:col-span-3 col-span-12 bg-primaryDark'>
                    <div>
                        <Sidebar />
                    </div>
                </div>
                <div className='lg:col-span-9 col-span-12'>
                    <Header />
                    <div className='container mx-auto p-5'>
                        <ProfileDetail />
                        <ProfileForm />
                    </div>
                </div>
            </div>

        </>
    )
}
export default Profile