import React, { useState } from 'react'
import Header from '../../shef_dashboard/components/Header'
import Sidebar from '../components/Sidebar'
import MenuStepFormModal from '../components/myMenu/MenuStepFormModal'
import Screen01 from '../components/myMenu/Screen01'
import Screen02 from '../components/myMenu/Screen02'
import Screen03 from '../components/myMenu/Screen03'
import Screen04 from '../components/myMenu/Screen04'
import Screen05 from '../components/myMenu/Screen05'
import Screen06 from '../components/myMenu/Screen06'


// const PriceStep = () => <div>Step 3 content</div>;
// const IngredientsStep = () => <div>Step 4 content</div>;
export const MyMenu = () => {
    const [isStepFormModalOpen, setStepFormModalOpen] = useState(false);
    const [currentStep, setCurrentStep] = useState(0);

    const steps = [
        { title: 'Dish Details', content: <Screen01 /> },
        { title: 'Description', content: <Screen02 /> },
        { title: 'More Information', content: <Screen03 /> },
        { title: 'Ingredients', content: <Screen04 /> },
        { title: 'Dietary', content: <Screen05 /> },
        { title: 'Photo', content: <Screen06 /> },
    ];

    const openStepFormModal = () => {
        setStepFormModalOpen(true);
    };

    const closeStepFormModal = () => {
        setStepFormModalOpen(false);
        setCurrentStep(0);
    };

    const nextStep = () => {
        setCurrentStep(currentStep + 1);
    };

    const prevStep = () => {
        setCurrentStep(currentStep - 1);
    };

   
    return (
        <div className=''>
            <div className='grid grid-cols-12'>
                <div className='lg:col-span-3 col-span-12'>
                    <div className=''>
                        <Sidebar />
                    </div>
                </div>
                <div className='lg:col-span-9 col-span-12 bg-[#f7f7f7]'>
                    <Header />
                    <div className='p-5'>
                        <div className='p-5 bg-white rounded-xl'>
                            <h3 className='text-xl font-semibold'>Filter</h3>
                            <div className='flex items-center gap-4'>
                                <div>
                                    <h4 className='font-medium text-base mb-1'>You can filter by weekday.</h4>
                                    <select id="selectOption" className=''>
                                        <option value="">Select Any Day</option>
                                        <option value="option1">Monday</option>
                                        <option value="option2">Tuesday</option>
                                        <option value="option3">Wednessday</option>
                                        <option value="option4">Thursday</option>
                                        <option value="option5">Friday</option>
                                        <option value="option6">Saturday</option>
                                        <option value="option7">Sunday</option>
                                    </select>
                                </div>
                                <div>
                                    <h4 className='font-medium text-base mb-1'>You can filter by food type..</h4>
                                    <select id="selectOption">
                                        <option value="">Select Food Type</option>
                                        <option value="option1">All</option>
                                        <option value="option2">Appetizer</option>
                                        <option value="option3">Beverage</option>
                                        <option value="option4">Dessert</option>
                                        <option value="option5">Kids</option>
                                        <option value="option6">Main</option>
                                        <option value="option7">Side</option>
                                    </select>
                                </div>
                                <div>
                                    <h4 className='font-medium text-base mb-1'>You can filter by Name.</h4>
                                    <input type="search" placeholder='Type Dish Name' id='' name='' />
                                </div>
                            </div>
                        </div>
                        <div className='mt-6 p-5 bg-white rounded-xl'>
                            <div className='flex justify-between gap-3 mb-4'>
                                <h3 className='text-xl font-semibold leading-tight pt-2 mb-0'>Dish Catalogue (0)</h3>
                                <button className='bg-primaryDark text-white text-base font-semibold rounded-full px-5 py-2' onClick={openStepFormModal}>Add New Dish</button>
                            </div>
                            <div>
                                <table class="text-left w-full menuTable border-0">
                                    <thead>
                                        <tr className='border-b'>
                                            <th>Image</th>
                                            <th>Price</th>
                                            <th>Action</th>
                                            <th>Description</th>
                                            <th>Available</th>
                                            <th>Days</th>
                                            <th>Delivery Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>The Sliding Mr. Bones (Next Stop, Pottersville)</td>
                                            <td>Malcolm Lockyer</td>
                                            <td>1961</td>
                                            <td>Malcolm Lockyer</td>
                                            <td>1961</td>
                                            <td>Malcolm Lockyer</td>
                                            <td>1961</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div>
                        <MenuStepFormModal isOpen={isStepFormModalOpen}
                            onClose={closeStepFormModal}
                            steps={steps}
                            currentStep={currentStep}
                            onNext={nextStep}
                            onBack={prevStep} />
                    </div>
                
                </div>

            </div>
        </div>
    )
}
export default MyMenu