import React, { useState } from 'react'
import Sidebar from '../../shef_dashboard/components/Sidebar';

export const ShefHome = () => {
    const [isSidebarExpend, setIsSidebarExpend] = useState(true);

    const sidebarExpendClick = () => {
        setIsSidebarExpend(!isSidebarExpend);
    };

    const leftColumnWidth = {
        width: isSidebarExpend ? '400px' : '100px',
        transition: 'width 0.5s ease-in-out', // Add a transition effect
    };

    const rightColumnWidth = {
        width: isSidebarExpend ? '100%' : '100%',
        transition: 'width 0.5s ease-in-out', // Add a transition effect
    };
    return (
        <div className='h-screen'>
            <div className='w-full flex h-full'>
                <div className='bg-primaryDark' style={leftColumnWidth}>
                    <div className='border-b border-borderClr px-4 h-[75px]'>
                        {isSidebarExpend && (
                            <div className='flex justify-between items-center gap-3 w-full h-full'>
                                <div className='font-bold text-white text-xl'>
                                    Admin Pannel
                                </div>
                                {/* <img src="/media/frontend/img/logo/line-logo.jpg" width='' className="img-fluid h-[40px]" alt="Logo" /> */}
                                <button className='bg-white p-1 rounded-md' onClick={sidebarExpendClick}>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="rgba(0,0,0,1)">
                                        <path d="M4.83578 12L11.0429 18.2071L12.4571 16.7929L7.66421 12L12.4571 7.20712L11.0429 5.79291L4.83578 12ZM10.4857 12L16.6928 18.2071L18.107 16.7929L13.3141 12L18.107 7.20712L16.6928 5.79291L10.4857 12Z"></path>
                                    </svg>
                                </button>
                            </div>
                        )}
                        {!isSidebarExpend && (
                            <div className='flex justify-between items-center gap-3 w-full h-full'>
                                <div className='font-bold text-white text-xl'>
                                    A
                                </div>
                                <button className='bg-white p-1 rounded-md' onClick={sidebarExpendClick}>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="rgba(0,0,0,1)">
                                        <path d="M19.1642 12L12.9571 5.79291L11.5429 7.20712L16.3358 12L11.5429 16.7929L12.9571 18.2071L19.1642 12ZM13.5143 12L7.30722 5.79291L5.89301 7.20712L10.6859 12L5.89301 16.7929L7.30722 18.2071L13.5143 12Z"></path>
                                    </svg>
                                </button>
                            </div>
                        )}
                    </div>
                    <Sidebar />
                </div>
                <div className='bg-primaryLight' style={rightColumnWidth}>
                    {/* Content for the right column */}
                </div>
            </div>
        </div>
    )
}
export default ShefHome